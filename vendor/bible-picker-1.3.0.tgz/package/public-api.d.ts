export * from './lib/bible-picker-lib.component';
export * from './lib/bible';
