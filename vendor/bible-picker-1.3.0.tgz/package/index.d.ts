/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="bible-picker" />
export * from './public-api';
