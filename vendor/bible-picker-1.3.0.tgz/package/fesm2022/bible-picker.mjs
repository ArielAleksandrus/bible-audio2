import * as i0 from '@angular/core';
import { input, output, effect, untracked, Component } from '@angular/core';

const BIBLE_CDN = 'https://pub-7db5ca77d7e14ca79a36013b9fc40870.r2.dev/jsons';
const BIBLE_VERSIONS = {
    'pt-ara': `${BIBLE_CDN}/pt-ara.json`,
    'en-niv': `${BIBLE_CDN}/en-niv.json`,
    'es-nvi': `${BIBLE_CDN}/es-nvi.json`,
    'ja-jcb': `${BIBLE_CDN}/ja-jcb.json`,
    'zh-cnvs': `${BIBLE_CDN}/zh-cnvs.json`,
};
const bibleJsonCache = new Map();
function bibleUrlFor(bversion) {
    const key = bversion.trim().toLowerCase();
    return BIBLE_VERSIONS[key];
}
function fetchBibleJson(url) {
    let pending = bibleJsonCache.get(url);
    if (!pending) {
        pending = fetch(url).then(async (response) => {
            if (!response.ok) {
                throw new Error(`Failed to load Bible JSON (${response.status} ${response.statusText})`);
            }
            return response.json();
        }).catch((err) => {
            bibleJsonCache.delete(url);
            throw err;
        });
        bibleJsonCache.set(url, pending);
    }
    return pending;
}
class Bible {
    version = 'none'; // 'Almeida Revista Atualizada (ARA)', 'Almeida Corrigida Fiel (ACF)', etc
    language = 'none'; // 'pt-br', 'en-us', etc
    books = [];
    static abbrevSelection(selection) {
        let res = "";
        const s = selection;
        if (s.books.length > 0) {
            res = s.books[0].abbrev;
            if (s.books.length > 1)
                res = res + "-" + s.books[s.books.length - 1].abbrev;
        }
        if (s.chapters.length > 0) {
            res = res + " " + String(s.chapters[0]);
            if (s.chapters.length > 1)
                res = res + "-" + String(s.chapters[s.chapters.length - 1]);
        }
        if (s.verses.length > 0) {
            res = res + ":" + String(s.verses[0]);
            if (s.verses.length > 1)
                res = res + "-" + String(s.verses[s.verses.length - 1]);
        }
        return res;
    }
    static getVerses(selection) {
        let res = [];
        const s = selection;
        const curBook = s.books[0];
        if (s.books.length > 0) {
            res = [{ abbrev: curBook.abbrev, text: curBook.chapters }];
            if (s.books.length > 1) {
                for (let i = 1; i < s.books.length; i++) {
                    res.push({ abbrev: s.books[i].abbrev, text: s.books[i].chapters });
                }
            }
        }
        if (s.chapters.length > 0) {
            const curChapter = curBook.chapters[s.chapters[0] - 1];
            res = [{ abbrev: curBook.abbrev, text: [curChapter] }];
            if (s.chapters.length > 1) {
                for (let i = 1; i < s.chapters.length; i++) {
                    res[0].text.push(curBook.chapters[s.chapters[i] - 1]);
                }
            }
            if (s.verses.length > 0) {
                const curVerse = curChapter[s.verses[0] - 1];
                res = [{ abbrev: curBook.abbrev, text: [[curVerse]] }];
                if (s.verses.length > 1) {
                    for (let i = 1; i < s.verses.length; i++) {
                        res[0].text[0].push(curChapter[s.verses[i] - 1]);
                    }
                }
            }
        }
        return res;
    }
}

const bibleTerms = {
    book: {
        "en": "books",
        "pt-br": "livros",
        "es": "libros",
        "zh": "书", // Em chinês, "书" já é usado tanto no singular quanto no plural em contextos bíblicos
        "ja": "書"
    },
    chapter: {
        "en": "chapters",
        "pt-br": "capítulos",
        "es": "capítulos",
        "zh": "章",
        "ja": "章"
    },
    verse: {
        "en": "verses",
        "pt-br": "versículos",
        "es": "versículos",
        "zh": "节",
        "ja": "節"
    }
};
// Section labels and button names. Languages the picker has no words for
// fall back to English.
const uiTerms = {
    "en": { ot: "Old Testament", nt: "New Testament", back: "Back", ok: "OK", loading: "Loading…" },
    "pt": { ot: "Antigo Testamento", nt: "Novo Testamento", back: "Voltar", ok: "OK", loading: "Carregando…" },
    "es": { ot: "Antiguo Testamento", nt: "Nuevo Testamento", back: "Volver", ok: "OK", loading: "Cargando…" },
    "zh": { ot: "旧约", nt: "新约", back: "返回", ok: "确定", loading: "加载中…" },
    "ja": { ot: "旧約聖書", nt: "新約聖書", back: "戻る", ok: "OK", loading: "読み込み中…" }
};
/** Books in the Old Testament of a 66-book (Protestant canon) Bible. */
const OLD_TESTAMENT_BOOKS = 39;
class BiblePicker {
    bible = input();
    bversion = input();
    jsonUrl = input();
    select = input('any');
    customCSS = input({ "b": {}, "c": {}, "v": {} });
    selectedBookStartIdx = -1;
    selectedBookEndIdx = -1;
    hoveredBook = -1;
    hoveredChapter = -1;
    hoveredVerse = -1;
    selectedBookStart;
    selectedChapterStart = -1;
    selectedVerseStart = -1;
    selectedBookEnd;
    selectedChapterEnd = -1;
    selectedVerseEnd = -1;
    onSelecting = output();
    onSelected = output();
    stage = 'book';
    title = "Book";
    /** What the current grid belongs to: the book in the chapter stage, "Book N" in the verse stage. */
    context = "";
    disable = true;
    resolved;
    loading = false;
    loadError;
    loadGen = 0;
    constructor() {
        effect(() => {
            const bible = this.bible();
            const jsonUrl = this.jsonUrl();
            const bversion = this.bversion();
            untracked(() => { void this.resolveSource(bible, jsonUrl, bversion); });
        });
    }
    ngOnInit() {
        this.changeTitle();
    }
    currentBible() {
        return this.resolved;
    }
    /** Words for the buttons and section labels, in the Bible's language. */
    get ui() {
        const lang = (this.resolved?.language || 'en').split('-')[0];
        return uiTerms[lang] || uiTerms['en'];
    }
    /**
     * True when OK is how the selection ends. In the single modes ('book',
     * 'chapter', 'verse') the click itself ends it, so no OK is shown.
     */
    get needsOk() {
        const sel = this.select();
        return sel !== 'book' && sel !== 'chapter' && sel !== 'verse';
    }
    term(kind) {
        const lang = this.resolved?.language || '';
        const words = bibleTerms[kind];
        return words[lang] || words[lang.split('-')[0]] || words[lang.split('-')[0] === 'pt' ? 'pt-br' : 'en'];
    }
    get chapterWord() { return this.term('chapter'); }
    get verseWord() { return this.term('verse'); }
    /** Book grids to draw: Old/New Testament for a 66-book Bible, else one unlabeled grid. */
    get bookGroups() {
        const books = this.resolved?.books || [];
        if (books.length !== 66)
            return [{ label: '', start: 0, books }];
        return [
            { label: this.ui.ot, start: 0, books: books.slice(0, OLD_TESTAMENT_BOOKS) },
            { label: this.ui.nt, start: OLD_TESTAMENT_BOOKS, books: books.slice(OLD_TESTAMENT_BOOKS) }
        ];
    }
    // Bible JSONs disagree on which field holds a book's name (some have only
    // "english"/"chinese"/"japanese"), and a few have no abbreviation.
    bookName(book) {
        const b = book;
        return b?.['name'] || b?.['chinese'] || b?.['japanese'] || b?.['english'] || b?.['abbrev'] || '';
    }
    bookAbbrev(book) {
        return book?.abbrev || this.bookName(book);
    }
    /**
     * Open a book's chapter grid from outside the picker (a search result, a
     * "continue reading" shortcut) and, optionally, mark one chapter. Emits
     * onSelecting like a click on the book would, but never onSelected.
     */
    showChapter(bookIdx, chapter) {
        const book = this.currentBible()?.books[bookIdx];
        if (!book)
            return;
        this.resetPicker();
        this.selectedBookStart = this.selectedBookEnd = book;
        this.selectedBookStartIdx = this.selectedBookEndIdx = bookIdx;
        this.stage = 'chapter';
        if (chapter && chapter >= 1 && chapter <= book.chapters.length)
            this.selectedChapterStart = chapter;
        this.changeTitle();
        this.send(false);
    }
    resetPicker() {
        this.stage = 'book';
        this.selectedBookStart = this.selectedBookEnd = undefined;
        this.selectedBookStartIdx = this.selectedBookEndIdx = this.hoveredBook = -1;
        this.selectedChapterStart = this.selectedChapterEnd = this.hoveredChapter = -1;
        this.selectedVerseStart = this.selectedVerseEnd = this.hoveredVerse = -1;
        this.disable = true;
    }
    applyBible(data) {
        const same = this.resolved === data;
        this.resolved = data;
        this.loading = false;
        this.loadError = undefined;
        if (!same)
            this.resetPicker();
        this.changeTitle();
    }
    async resolveSource(bible, jsonUrl, bversion) {
        const gen = ++this.loadGen;
        if (bible) {
            this.applyBible(bible);
            return;
        }
        const url = jsonUrl?.trim() || (bversion ? bibleUrlFor(bversion) : undefined);
        if (!url) {
            this.resolved = undefined;
            this.loading = false;
            this.resetPicker();
            this.loadError = bversion
                ? `Unknown bversion "${bversion}". Known versions: ${Object.keys(BIBLE_VERSIONS).join(', ')}`
                : 'Pass [bible], [bversion], or [jsonUrl].';
            this.title = 'Book';
            return;
        }
        this.resetPicker();
        this.loading = true;
        this.loadError = undefined;
        try {
            const data = await fetchBibleJson(url);
            if (gen !== this.loadGen)
                return;
            this.applyBible(data);
        }
        catch (err) {
            if (gen !== this.loadGen)
                return;
            this.resolved = undefined;
            this.loading = false;
            this.resetPicker();
            this.loadError = err?.message || `Failed to load Bible from ${url}`;
            this.title = 'Book';
        }
    }
    send(final) {
        let res = {
            books: [],
            chapters: [],
            verses: []
        };
        let bsi = this.selectedBookStartIdx, bei = this.selectedBookEndIdx;
        let csi = this.selectedChapterStart, cei = this.selectedChapterEnd;
        let vsi = this.selectedVerseStart, vei = this.selectedVerseEnd;
        if (bei == -1)
            bei = bsi;
        for (let i = this.selectedBookStartIdx; i <= bei; i++) {
            let book = this.currentBible().books[i];
            if (book)
                res.books.push(book);
        }
        if (csi > -1) {
            if (cei == -1)
                cei = csi;
            for (let i = csi; i <= cei; i++) {
                res.chapters.push(i);
            }
        }
        if (vsi > -1) {
            if (vei == -1)
                vei = vsi;
            for (let i = vsi; i <= vei; i++) {
                res.verses.push(i);
            }
        }
        if (final) {
            this.onSelected.emit(res);
        }
        else
            this.onSelecting.emit(res);
    }
    changeTitle() {
        //@ts-ignore
        const bible = this.currentBible();
        //@ts-ignore
        this.title = (bible && bibleTerms[this.stage][bible.language]) || '';
        this.context = '';
        if (this.stage == "chapter") {
            this.title += ` (${this.selectedBookStart?.abbrev})`;
            this.context = this.bookName(this.selectedBookStart);
        }
        else if (this.stage == "verse") {
            this.title += ` (${this.selectedBookStart?.abbrev}.${this.selectedChapterStart})`;
            this.context = `${this.bookName(this.selectedBookStart)} ${this.selectedChapterStart}`;
        }
    }
    goBack() {
        this.disable = true;
        if (this.stage == "verse") {
            this.selectedVerseStart = this.selectedVerseEnd = this.selectedChapterStart = this.selectedChapterEnd = this.hoveredChapter = -1;
            this.stage = "chapter";
        }
        else if (this.stage == "chapter") {
            this.selectedBookStart = this.selectedBookEnd = undefined;
            this.selectedBookStartIdx = this.selectedBookEndIdx = -1;
            this.selectedChapterStart = this.selectedChapterEnd = this.hoveredBook = this.hoveredChapter = -1;
            this.disable = true;
            this.stage = "book";
        }
        this.changeTitle();
        this.send(false);
    }
    hoverBook(idx) {
        let sel = this.select();
        let si = this.selectedBookStartIdx;
        let ei = this.selectedBookEndIdx;
        if (si >= 0 && ei == -1) { // só se start is set e end is not set.
            if (sel != "book") // só se sel não for book, porque se for, o usuário não pode ver hover ao arrastar o mouse para clicar em ok
                this.hoveredBook = idx;
        }
    }
    hoverChapter(idx) {
        let sel = this.select();
        if (this.selectedChapterStart >= 0 && this.selectedChapterEnd == -1) {
            if (sel != "chapter")
                this.hoveredChapter = idx;
        }
    }
    hoverVerse(idx) {
        let sel = this.select();
        if (this.selectedVerseStart >= 0 && this.selectedVerseEnd == -1) {
            if (sel != "verse")
                this.hoveredVerse = idx;
        }
    }
    selectBook(book) {
        let si = this.selectedBookStartIdx;
        let ei = this.selectedBookEndIdx;
        const i = this.currentBible().books.indexOf(book);
        const sel = this.select();
        this.disable = true;
        if (si == -1) {
            this.selectedBookStart = book;
            si = this.selectedBookStartIdx = i;
            if (sel == "any") {
                this.disable = false;
                this.send(false);
                return;
            }
            else if (sel == "book") {
                this.send(true);
                return;
            }
            else if (sel == "books") {
                this.disable = false;
                this.send(false);
                return;
            }
            else {
                this.selectedBookEnd = book;
                this.selectedBookEndIdx = i;
                this.stage = "chapter";
                this.changeTitle();
                this.send(false);
                return;
            }
        }
        if (ei == -1) {
            //this.selectedBookEnd = book;
            ei = this.selectedBookEndIdx = i;
            if (ei < si) {
                this.selectedBookStart = this.selectedBookEnd = undefined;
                this.selectedBookStartIdx = this.selectedBookEndIdx = -1;
                this.selectBook(book);
                return;
            }
            else if (ei == si) {
                if (sel == "any") {
                    this.stage = "chapter";
                    this.changeTitle();
                    this.send(false);
                    return;
                }
            }
            this.selectedBookEnd = book;
            this.selectedBookEndIdx = i;
            this.disable = false;
            this.send(false);
            return;
        }
        if (si > -1 && ei > -1) {
            this.selectedBookStart = this.selectedBookEnd = undefined;
            this.selectedBookStartIdx = this.selectedBookEndIdx = this.hoveredBook = -1;
            this.selectBook(book);
            return;
        }
    }
    selectChapter(chapter) {
        let si = this.selectedChapterStart;
        let ei = this.selectedChapterEnd;
        const i = chapter;
        const sel = this.select();
        this.disable = true;
        if (si == -1) {
            si = this.selectedChapterStart = i;
            if (sel == "any") {
                this.disable = false;
                this.send(false);
                return;
            }
            else if (sel == "chapter") {
                this.send(true);
                return;
            }
            else if (sel == "chapters") {
                this.disable = false;
                this.send(false);
                return;
            }
            else {
                this.selectedChapterEnd = i;
                this.stage = "verse";
                this.changeTitle();
                this.send(false);
                return;
            }
        }
        if (ei == -1) {
            ei = this.selectedChapterEnd = i;
            if (ei < si) {
                this.selectedChapterStart = this.selectedChapterEnd = -1;
                this.selectChapter(chapter);
                return;
            }
            else if (ei == si) {
                if (sel == "any") {
                    this.stage = "verse";
                    this.changeTitle();
                    this.send(false);
                    return;
                }
            }
            this.selectedChapterEnd = i;
            this.disable = false;
            this.send(false);
            return;
        }
        if (si > -1 && ei > -1) {
            this.selectedChapterStart = this.selectedChapterEnd = this.hoveredChapter = -1;
            this.selectChapter(chapter);
            return;
        }
    }
    selectVerse(verse) {
        let si = this.selectedVerseStart;
        let ei = this.selectedVerseEnd;
        const i = verse;
        const sel = this.select();
        this.disable = true;
        if (si == -1) {
            si = this.selectedVerseStart = i;
            if (sel == "any") {
                this.disable = false;
                this.send(false);
                return;
            }
            else if (sel == "verse") {
                this.send(true);
                return;
            }
            else if (sel == "verses") {
                this.disable = false;
                this.send(false);
                return;
            }
            else {
                // will never reach here.
            }
        }
        if (ei == -1) {
            ei = this.selectedVerseEnd = i;
            if (ei < si) {
                this.selectedVerseStart = this.selectedVerseEnd = -1;
                this.selectVerse(verse);
                return;
            }
            else if (ei == si) {
                if (sel == "any") {
                    this.send(false);
                    return;
                }
            }
            this.selectedVerseEnd = i;
            this.disable = false;
            this.send(false);
            return;
        }
        if (si > -1 && ei > -1) {
            this.selectedVerseStart = this.selectedVerseEnd = this.hoveredVerse = -1;
            this.selectVerse(verse);
            return;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.5", ngImport: i0, type: BiblePicker, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.5", type: BiblePicker, isStandalone: true, selector: "bible-picker", inputs: { bible: { classPropertyName: "bible", publicName: "bible", isSignal: true, isRequired: false, transformFunction: null }, bversion: { classPropertyName: "bversion", publicName: "bversion", isSignal: true, isRequired: false, transformFunction: null }, jsonUrl: { classPropertyName: "jsonUrl", publicName: "jsonUrl", isSignal: true, isRequired: false, transformFunction: null }, select: { classPropertyName: "select", publicName: "select", isSignal: true, isRequired: false, transformFunction: null }, customCSS: { classPropertyName: "customCSS", publicName: "customCSS", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onSelecting: "onSelecting", onSelected: "onSelected" }, ngImport: i0, template: "<div class=\"bible-picker\">\n  <div class=\"picker-card\">\n    <header class=\"picker-header\">\n      @if (stage !== 'book') {\n        <button type=\"button\" class=\"btn btn-secondary btn-back\" (click)=\"goBack()\" [attr.aria-label]=\"ui.back\">\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M15 5l-7 7 7 7\" /></svg>\n        </button>\n      }\n      <h3 class=\"picker-title\" [attr.title]=\"title\">\n        @if (context) {\n          <span class=\"picker-context\">{{ context }}</span>\n          <span class=\"picker-stage\">{{ resolved ? (stage === 'chapter' ? chapterWord : verseWord) : '' }}</span>\n        } @else {\n          {{ title }}\n        }\n      </h3>\n      @if (needsOk) {\n        <div class=\"actions\">\n          <button type=\"button\" class=\"btn btn-primary\" [disabled]=\"disable\" (click)=\"send(true)\">\n            {{ ui.ok }}\n          </button>\n        </div>\n      }\n    </header>\n\n    <main class=\"picker-content\">\n      @if (loadError) {\n        <p class=\"picker-status picker-error\" role=\"alert\">{{ loadError }}</p>\n      } @else if (loading || !resolved) {\n        <p class=\"picker-status\">{{ ui.loading }}</p>\n      } @else {\n        <!-- Livros -->\n        @if (stage === 'book') {\n          @for (group of bookGroups; track group.start) {\n            @if (group.label) {\n              <h4 class=\"group-label\">{{ group.label }}</h4>\n            }\n            <div class=\"grid-container book-grid\">\n              @for (book of group.books; track book; let j = $index) {\n                <button\n                  type=\"button\"\n                  class=\"grid-item book-item\"\n                  [class.selected-start]=\"book === selectedBookStart\"\n                  [class.selected-range]=\"group.start + j > selectedBookStartIdx && group.start + j <= (selectedBookEndIdx > -1 ? selectedBookEndIdx : hoveredBook)\"\n                  [attr.aria-pressed]=\"book === selectedBookStart\"\n                  [attr.title]=\"bookName(book)\"\n                  [style]=\"customCSS()['b'][group.start + j]\"\n                  (click)=\"selectBook(book)\"\n                  (mouseenter)=\"hoverBook(group.start + j)\"\n                >\n                  <span class=\"book-abbrev\">{{ bookAbbrev(book) }}</span>\n                  @if (bookName(book) !== bookAbbrev(book)) {\n                    <span class=\"book-name\">{{ bookName(book) }}</span>\n                  }\n                </button>\n              }\n            </div>\n          }\n        }\n\n        <!-- Cap\u00EDtulos -->\n        @if (stage === 'chapter' && selectedBookStart) {\n          <div class=\"grid-container number-grid\">\n            @for (chapter of selectedBookStart.chapters; track $index; let i = $index) {\n              <button\n                type=\"button\"\n                class=\"grid-item chapter-item\"\n                [class.selected-start]=\"i === selectedChapterStart - 1\"\n                [class.selected-range]=\"i > selectedChapterStart - 1 && i <= (selectedChapterEnd > -1 ? selectedChapterEnd - 1 : hoveredChapter)\"\n                [attr.aria-pressed]=\"i === selectedChapterStart - 1\"\n                [style]=\"customCSS()['c'][i]\"\n                (click)=\"selectChapter(i + 1)\"\n                (mouseenter)=\"hoverChapter(i)\"\n              >\n                {{ i + 1 }}\n              </button>\n            }\n          </div>\n        }\n\n        <!-- Vers\u00EDculos -->\n        @if (stage === 'verse' && selectedBookStart && selectedChapterStart) {\n          <div class=\"grid-container number-grid\">\n            @for (verse of selectedBookStart.chapters[selectedChapterStart - 1]; track $index; let i = $index) {\n              <button\n                type=\"button\"\n                class=\"grid-item verse-item\"\n                [class.selected-start]=\"i === selectedVerseStart - 1\"\n                [class.selected-range]=\"i > selectedVerseStart - 1 && i <= (selectedVerseEnd > -1 ? selectedVerseEnd - 1 : hoveredVerse)\"\n                [attr.aria-pressed]=\"i === selectedVerseStart - 1\"\n                [style]=\"customCSS()['v'][i]\"\n                (click)=\"selectVerse(i + 1)\"\n                (mouseenter)=\"hoverVerse(i)\"\n              >\n                {{ i + 1 }}\n              </button>\n            }\n          </div>\n        }\n      }\n    </main>\n\n    @if (needsOk) {\n      <footer class=\"picker-footer\">\n        <div class=\"actions\">\n          @if (stage !== 'book') {\n            <button type=\"button\" class=\"btn btn-secondary\" (click)=\"goBack()\">\n              {{ ui.back }}\n            </button>\n          }\n          <button type=\"button\" class=\"btn btn-primary\" [disabled]=\"disable\" (click)=\"send(true)\">\n            {{ ui.ok }}\n          </button>\n        </div>\n      </footer>\n    }\n  </div>\n</div>\n", styles: [":host{display:block;--_primary: var(--bp-primary, var(--ion-color-primary, #0f3d3e));--_on-primary: var(--bp-on-primary, var(--ion-color-primary-contrast, #fff));--_surface: var(--bp-surface, #fff);--_item: var(--bp-item-bg, #f2f5f5);--_text: var(--bp-text, #1f2a2b);--_muted: var(--bp-muted, #5d6b6c);--_radius: var(--bp-radius, 12px)}.bible-picker{max-width:var(--bp-max-width, 720px);margin:0 auto;font-family:var(--bp-font, var(--ion-font-family, system-ui, -apple-system, \"Segoe UI\", Roboto, sans-serif));color:var(--_text)}.picker-card{background:var(--_surface);border-radius:var(--_radius);overflow:hidden}.picker-header{display:flex;align-items:center;gap:8px;min-height:56px;padding:6px 12px;background:var(--_primary);color:var(--_on-primary)}.picker-header .picker-title{flex:1;min-width:0;margin:0;font-size:1.1rem;font-weight:600;line-height:1.25;text-transform:capitalize;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.picker-header .picker-context,.picker-header .picker-stage{display:block;overflow:hidden;text-overflow:ellipsis}.picker-header .picker-stage{font-size:.78rem;font-weight:400;opacity:.85}.picker-content{padding:12px;min-height:240px}.picker-status{margin:40px 0;text-align:center;color:var(--_muted)}.picker-error{color:#b3261e}.group-label{margin:14px 2px 8px;font-size:.78rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--_muted)}.group-label:first-child{margin-top:2px}.grid-container{display:grid;gap:8px}.book-grid{grid-template-columns:repeat(auto-fill,minmax(96px,1fr))}.number-grid{grid-template-columns:repeat(auto-fill,minmax(52px,1fr))}.grid-item{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:0;min-height:48px;margin:0;padding:6px 8px;border:1px solid transparent;border-radius:10px;background:var(--_item);color:inherit;font:inherit;font-size:1rem;font-weight:600;font-variant-numeric:tabular-nums;cursor:pointer;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent;transition:background-color .15s ease,border-color .15s ease}.grid-item:after{content:\"\";position:absolute;top:5px;right:5px;width:8px;height:8px;border-radius:50%;background:var(--bp-mark, transparent);box-shadow:inset 0 0 0 2px var(--bp-mark-ring, transparent)}@media(hover:hover){.grid-item:hover{border-color:var(--_primary)}}.grid-item:focus-visible{outline:3px solid var(--bp-focus, #f2a900);outline-offset:2px}.grid-item:active{border-color:var(--_primary)}.grid-item.selected-range{background:color-mix(in srgb,var(--_primary) 18%,var(--_surface));border-color:color-mix(in srgb,var(--_primary) 35%,var(--_surface))}.grid-item.selected-start{background:var(--_primary)!important;border-color:var(--_primary);color:var(--_on-primary)}.book-item{min-height:56px;padding:8px 6px}.book-item .book-abbrev{font-size:1rem;line-height:1.2}.book-item .book-name{max-width:100%;font-size:.72rem;font-weight:400;line-height:1.3;color:var(--_muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.book-item.selected-start .book-name{color:inherit;opacity:.9}.picker-footer{padding:10px 12px;border-top:1px solid rgba(0,0,0,.08)}.picker-footer .actions{display:flex;justify-content:flex-end;gap:8px}.btn{display:inline-flex;align-items:center;justify-content:center;min-width:44px;min-height:44px;padding:0 16px;border:none;border-radius:22px;font:inherit;font-size:.95rem;font-weight:600;cursor:pointer;-webkit-tap-highlight-color:transparent}.btn:focus-visible{outline:3px solid var(--bp-focus, #f2a900);outline-offset:2px}.btn.btn-primary{background:var(--_primary);color:var(--_on-primary)}.btn.btn-primary:disabled{opacity:.45;cursor:not-allowed}.btn.btn-secondary{background:var(--_item);color:var(--_text)}.btn svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}.picker-header .btn.btn-back{padding:0;background:color-mix(in srgb,var(--_on-primary) 16%,transparent);color:var(--_on-primary)}.picker-header .btn.btn-primary{background:var(--_on-primary);color:var(--_primary)}@media(max-width:380px){.picker-content{padding:8px}.grid-container{gap:6px}.book-grid{grid-template-columns:repeat(auto-fill,minmax(84px,1fr))}.number-grid{grid-template-columns:repeat(auto-fill,minmax(46px,1fr))}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.5", ngImport: i0, type: BiblePicker, decorators: [{
            type: Component,
            args: [{ selector: 'bible-picker', imports: [], template: "<div class=\"bible-picker\">\n  <div class=\"picker-card\">\n    <header class=\"picker-header\">\n      @if (stage !== 'book') {\n        <button type=\"button\" class=\"btn btn-secondary btn-back\" (click)=\"goBack()\" [attr.aria-label]=\"ui.back\">\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M15 5l-7 7 7 7\" /></svg>\n        </button>\n      }\n      <h3 class=\"picker-title\" [attr.title]=\"title\">\n        @if (context) {\n          <span class=\"picker-context\">{{ context }}</span>\n          <span class=\"picker-stage\">{{ resolved ? (stage === 'chapter' ? chapterWord : verseWord) : '' }}</span>\n        } @else {\n          {{ title }}\n        }\n      </h3>\n      @if (needsOk) {\n        <div class=\"actions\">\n          <button type=\"button\" class=\"btn btn-primary\" [disabled]=\"disable\" (click)=\"send(true)\">\n            {{ ui.ok }}\n          </button>\n        </div>\n      }\n    </header>\n\n    <main class=\"picker-content\">\n      @if (loadError) {\n        <p class=\"picker-status picker-error\" role=\"alert\">{{ loadError }}</p>\n      } @else if (loading || !resolved) {\n        <p class=\"picker-status\">{{ ui.loading }}</p>\n      } @else {\n        <!-- Livros -->\n        @if (stage === 'book') {\n          @for (group of bookGroups; track group.start) {\n            @if (group.label) {\n              <h4 class=\"group-label\">{{ group.label }}</h4>\n            }\n            <div class=\"grid-container book-grid\">\n              @for (book of group.books; track book; let j = $index) {\n                <button\n                  type=\"button\"\n                  class=\"grid-item book-item\"\n                  [class.selected-start]=\"book === selectedBookStart\"\n                  [class.selected-range]=\"group.start + j > selectedBookStartIdx && group.start + j <= (selectedBookEndIdx > -1 ? selectedBookEndIdx : hoveredBook)\"\n                  [attr.aria-pressed]=\"book === selectedBookStart\"\n                  [attr.title]=\"bookName(book)\"\n                  [style]=\"customCSS()['b'][group.start + j]\"\n                  (click)=\"selectBook(book)\"\n                  (mouseenter)=\"hoverBook(group.start + j)\"\n                >\n                  <span class=\"book-abbrev\">{{ bookAbbrev(book) }}</span>\n                  @if (bookName(book) !== bookAbbrev(book)) {\n                    <span class=\"book-name\">{{ bookName(book) }}</span>\n                  }\n                </button>\n              }\n            </div>\n          }\n        }\n\n        <!-- Cap\u00EDtulos -->\n        @if (stage === 'chapter' && selectedBookStart) {\n          <div class=\"grid-container number-grid\">\n            @for (chapter of selectedBookStart.chapters; track $index; let i = $index) {\n              <button\n                type=\"button\"\n                class=\"grid-item chapter-item\"\n                [class.selected-start]=\"i === selectedChapterStart - 1\"\n                [class.selected-range]=\"i > selectedChapterStart - 1 && i <= (selectedChapterEnd > -1 ? selectedChapterEnd - 1 : hoveredChapter)\"\n                [attr.aria-pressed]=\"i === selectedChapterStart - 1\"\n                [style]=\"customCSS()['c'][i]\"\n                (click)=\"selectChapter(i + 1)\"\n                (mouseenter)=\"hoverChapter(i)\"\n              >\n                {{ i + 1 }}\n              </button>\n            }\n          </div>\n        }\n\n        <!-- Vers\u00EDculos -->\n        @if (stage === 'verse' && selectedBookStart && selectedChapterStart) {\n          <div class=\"grid-container number-grid\">\n            @for (verse of selectedBookStart.chapters[selectedChapterStart - 1]; track $index; let i = $index) {\n              <button\n                type=\"button\"\n                class=\"grid-item verse-item\"\n                [class.selected-start]=\"i === selectedVerseStart - 1\"\n                [class.selected-range]=\"i > selectedVerseStart - 1 && i <= (selectedVerseEnd > -1 ? selectedVerseEnd - 1 : hoveredVerse)\"\n                [attr.aria-pressed]=\"i === selectedVerseStart - 1\"\n                [style]=\"customCSS()['v'][i]\"\n                (click)=\"selectVerse(i + 1)\"\n                (mouseenter)=\"hoverVerse(i)\"\n              >\n                {{ i + 1 }}\n              </button>\n            }\n          </div>\n        }\n      }\n    </main>\n\n    @if (needsOk) {\n      <footer class=\"picker-footer\">\n        <div class=\"actions\">\n          @if (stage !== 'book') {\n            <button type=\"button\" class=\"btn btn-secondary\" (click)=\"goBack()\">\n              {{ ui.back }}\n            </button>\n          }\n          <button type=\"button\" class=\"btn btn-primary\" [disabled]=\"disable\" (click)=\"send(true)\">\n            {{ ui.ok }}\n          </button>\n        </div>\n      </footer>\n    }\n  </div>\n</div>\n", styles: [":host{display:block;--_primary: var(--bp-primary, var(--ion-color-primary, #0f3d3e));--_on-primary: var(--bp-on-primary, var(--ion-color-primary-contrast, #fff));--_surface: var(--bp-surface, #fff);--_item: var(--bp-item-bg, #f2f5f5);--_text: var(--bp-text, #1f2a2b);--_muted: var(--bp-muted, #5d6b6c);--_radius: var(--bp-radius, 12px)}.bible-picker{max-width:var(--bp-max-width, 720px);margin:0 auto;font-family:var(--bp-font, var(--ion-font-family, system-ui, -apple-system, \"Segoe UI\", Roboto, sans-serif));color:var(--_text)}.picker-card{background:var(--_surface);border-radius:var(--_radius);overflow:hidden}.picker-header{display:flex;align-items:center;gap:8px;min-height:56px;padding:6px 12px;background:var(--_primary);color:var(--_on-primary)}.picker-header .picker-title{flex:1;min-width:0;margin:0;font-size:1.1rem;font-weight:600;line-height:1.25;text-transform:capitalize;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.picker-header .picker-context,.picker-header .picker-stage{display:block;overflow:hidden;text-overflow:ellipsis}.picker-header .picker-stage{font-size:.78rem;font-weight:400;opacity:.85}.picker-content{padding:12px;min-height:240px}.picker-status{margin:40px 0;text-align:center;color:var(--_muted)}.picker-error{color:#b3261e}.group-label{margin:14px 2px 8px;font-size:.78rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--_muted)}.group-label:first-child{margin-top:2px}.grid-container{display:grid;gap:8px}.book-grid{grid-template-columns:repeat(auto-fill,minmax(96px,1fr))}.number-grid{grid-template-columns:repeat(auto-fill,minmax(52px,1fr))}.grid-item{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:0;min-height:48px;margin:0;padding:6px 8px;border:1px solid transparent;border-radius:10px;background:var(--_item);color:inherit;font:inherit;font-size:1rem;font-weight:600;font-variant-numeric:tabular-nums;cursor:pointer;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent;transition:background-color .15s ease,border-color .15s ease}.grid-item:after{content:\"\";position:absolute;top:5px;right:5px;width:8px;height:8px;border-radius:50%;background:var(--bp-mark, transparent);box-shadow:inset 0 0 0 2px var(--bp-mark-ring, transparent)}@media(hover:hover){.grid-item:hover{border-color:var(--_primary)}}.grid-item:focus-visible{outline:3px solid var(--bp-focus, #f2a900);outline-offset:2px}.grid-item:active{border-color:var(--_primary)}.grid-item.selected-range{background:color-mix(in srgb,var(--_primary) 18%,var(--_surface));border-color:color-mix(in srgb,var(--_primary) 35%,var(--_surface))}.grid-item.selected-start{background:var(--_primary)!important;border-color:var(--_primary);color:var(--_on-primary)}.book-item{min-height:56px;padding:8px 6px}.book-item .book-abbrev{font-size:1rem;line-height:1.2}.book-item .book-name{max-width:100%;font-size:.72rem;font-weight:400;line-height:1.3;color:var(--_muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.book-item.selected-start .book-name{color:inherit;opacity:.9}.picker-footer{padding:10px 12px;border-top:1px solid rgba(0,0,0,.08)}.picker-footer .actions{display:flex;justify-content:flex-end;gap:8px}.btn{display:inline-flex;align-items:center;justify-content:center;min-width:44px;min-height:44px;padding:0 16px;border:none;border-radius:22px;font:inherit;font-size:.95rem;font-weight:600;cursor:pointer;-webkit-tap-highlight-color:transparent}.btn:focus-visible{outline:3px solid var(--bp-focus, #f2a900);outline-offset:2px}.btn.btn-primary{background:var(--_primary);color:var(--_on-primary)}.btn.btn-primary:disabled{opacity:.45;cursor:not-allowed}.btn.btn-secondary{background:var(--_item);color:var(--_text)}.btn svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}.picker-header .btn.btn-back{padding:0;background:color-mix(in srgb,var(--_on-primary) 16%,transparent);color:var(--_on-primary)}.picker-header .btn.btn-primary{background:var(--_on-primary);color:var(--_primary)}@media(max-width:380px){.picker-content{padding:8px}.grid-container{gap:6px}.book-grid{grid-template-columns:repeat(auto-fill,minmax(84px,1fr))}.number-grid{grid-template-columns:repeat(auto-fill,minmax(46px,1fr))}}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Public API Surface of bible-picker-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BIBLE_VERSIONS, Bible, BiblePicker, bibleUrlFor, fetchBibleJson };
//# sourceMappingURL=bible-picker.mjs.map
