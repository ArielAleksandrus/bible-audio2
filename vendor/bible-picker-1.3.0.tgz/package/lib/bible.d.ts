export type BibleBook = {
    abbrev: string;
    name: string;
    chapters: Array<Array<string>>;
};
export type SelectedText = {
    abbrev: string;
    text: string[][];
};
export type BibleJSON = {
    version: string;
    language: string;
    books: BibleBook[];
};
export type BibleSelection = {
    books: BibleBook[];
    chapters: number[];
    verses: number[];
};
export declare const BIBLE_VERSIONS: {
    readonly 'pt-ara': "https://pub-7db5ca77d7e14ca79a36013b9fc40870.r2.dev/jsons/pt-ara.json";
    readonly 'en-niv': "https://pub-7db5ca77d7e14ca79a36013b9fc40870.r2.dev/jsons/en-niv.json";
    readonly 'es-nvi': "https://pub-7db5ca77d7e14ca79a36013b9fc40870.r2.dev/jsons/es-nvi.json";
    readonly 'ja-jcb': "https://pub-7db5ca77d7e14ca79a36013b9fc40870.r2.dev/jsons/ja-jcb.json";
    readonly 'zh-cnvs': "https://pub-7db5ca77d7e14ca79a36013b9fc40870.r2.dev/jsons/zh-cnvs.json";
};
export type KnownBibleVersion = keyof typeof BIBLE_VERSIONS;
export declare function bibleUrlFor(bversion: string): string | undefined;
export declare function fetchBibleJson(url: string): Promise<Bible>;
export declare class Bible {
    version: string;
    language: string;
    books: BibleBook[];
    static abbrevSelection(selection: BibleSelection): string;
    static getVerses(selection: BibleSelection): SelectedText[];
}
