import { Bible, BibleBook, BibleSelection } from './bible';
import * as i0 from "@angular/core";
export type OverridableCSS = {
    "b": {
        [idx: number]: string;
    };
    "c": {
        [idx: number]: string;
    };
    "v": {
        [idx: number]: string;
    };
};
export declare class BiblePicker {
    bible: import("@angular/core").InputSignal<Bible | undefined>;
    bversion: import("@angular/core").InputSignal<string | undefined>;
    jsonUrl: import("@angular/core").InputSignal<string | undefined>;
    select: import("@angular/core").InputSignal<"books" | "chapters" | "verses" | "book" | "chapter" | "verse" | "any">;
    customCSS: import("@angular/core").InputSignal<OverridableCSS>;
    selectedBookStartIdx: number;
    selectedBookEndIdx: number;
    hoveredBook: number;
    hoveredChapter: number;
    hoveredVerse: number;
    selectedBookStart?: BibleBook;
    selectedChapterStart: number;
    selectedVerseStart: number;
    selectedBookEnd?: BibleBook;
    selectedChapterEnd: number;
    selectedVerseEnd: number;
    onSelecting: import("@angular/core").OutputEmitterRef<BibleSelection>;
    onSelected: import("@angular/core").OutputEmitterRef<BibleSelection>;
    stage: 'book' | 'chapter' | 'verse';
    title: string;
    /** What the current grid belongs to: the book in the chapter stage, "Book N" in the verse stage. */
    context: string;
    disable: boolean;
    resolved?: Bible;
    loading: boolean;
    loadError?: string;
    private loadGen;
    constructor();
    ngOnInit(): void;
    currentBible(): Bible | undefined;
    /** Words for the buttons and section labels, in the Bible's language. */
    get ui(): {
        ot: string;
        nt: string;
        back: string;
        ok: string;
        loading: string;
    };
    /**
     * True when OK is how the selection ends. In the single modes ('book',
     * 'chapter', 'verse') the click itself ends it, so no OK is shown.
     */
    get needsOk(): boolean;
    private term;
    get chapterWord(): string;
    get verseWord(): string;
    /** Book grids to draw: Old/New Testament for a 66-book Bible, else one unlabeled grid. */
    get bookGroups(): {
        label: string;
        start: number;
        books: BibleBook[];
    }[];
    bookName(book?: BibleBook): string;
    bookAbbrev(book?: BibleBook): string;
    /**
     * Open a book's chapter grid from outside the picker (a search result, a
     * "continue reading" shortcut) and, optionally, mark one chapter. Emits
     * onSelecting like a click on the book would, but never onSelected.
     */
    showChapter(bookIdx: number, chapter?: number): void;
    private resetPicker;
    private applyBible;
    private resolveSource;
    send(final: boolean): void;
    changeTitle(): void;
    goBack(): void;
    hoverBook(idx: number): void;
    hoverChapter(idx: number): void;
    hoverVerse(idx: number): void;
    selectBook(book: BibleBook): any;
    selectChapter(chapter: number): void;
    selectVerse(verse: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiblePicker, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiblePicker, "bible-picker", never, { "bible": { "alias": "bible"; "required": false; "isSignal": true; }; "bversion": { "alias": "bversion"; "required": false; "isSignal": true; }; "jsonUrl": { "alias": "jsonUrl"; "required": false; "isSignal": true; }; "select": { "alias": "select"; "required": false; "isSignal": true; }; "customCSS": { "alias": "customCSS"; "required": false; "isSignal": true; }; }, { "onSelecting": "onSelecting"; "onSelected": "onSelected"; }, never, never, true, never>;
}
